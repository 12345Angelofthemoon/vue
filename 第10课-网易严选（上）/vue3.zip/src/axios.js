import Axios from 'axios';

export default Axios.create({
  baseURL: 'http://api.zhinengshe.com/study/vue1/you163/'
});
