<template lang="html">
  <el-card class="reg-card">
    <div slot="header" class="header">
      <strong>简历填写</strong>
    </div>
    <el-steps :active="step" align-center simple>
      <el-step title="基本信息"></el-step>
      <el-step title="教育经历"></el-step>
      <el-step title="工作经验"></el-step>
      <el-step title="完成"></el-step>
    </el-steps>
    {{this.form}}

    <el-form label-width="70px" class="form" v-if="step==0">
      <el-form-item label="姓名">
        <el-input v-model="form.name" placeholder="请输入姓名"></el-input>
      </el-form-item>
      <el-form-item label="性别">
        <el-radio-group v-model="form.gender">
          <el-radio
            v-for="txt,value in metas.genders"
            :label="value"
            :key="value"
          >
            {{txt}}
          </el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="熟悉语言">
        <el-checkbox-group v-model="form.languages">
          <el-checkbox
            v-for="txt, value in metas.languages"
            :key="value"
            :label="value"
          >
            {{txt}}
          </el-checkbox>
        </el-checkbox-group>
      </el-form-item>
      <el-form-item label="年龄">
        <el-input-number v-model="form.age" :min="18" :max="65"></el-input-number>
      </el-form-item>
      <el-form-item label="职位">
        <el-select v-model="form.job">
          <el-option
            v-for="val,key in metas.jobs"
            :key="key"
            :label="val"
            :value="key"
          >
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="接受调岗">
        <el-switch
          v-model="form.accept"
        >
        </el-switch>
      </el-form-item>
      <el-form-item label="期望薪资">
        <el-slider v-model="form.salary" :min="5000" :max="30000" :step="1000"></el-slider>
      </el-form-item>
      <el-form-item label="预约时间">
        <el-time-select
          v-model="form.time"
          :picker-options="{
            start: '06:00',
            end: '23:00',
            step: '01:00'
          }"
        >
        </el-time-select>
      </el-form-item>
    </el-form>


    <el-form label-width="70px" class="form" v-if="step==1">
      <el-button @click="educations++;form.educations.push({})">添加一项</el-button>
      <el-collapse>
        <el-collapse-item v-for="i in educations">
          <el-form-item label="学历">
            <el-select v-model="form.educations[i-1].education">
              <el-option
                v-for="val,key in metas.educations"
                :key="key"
                :label="val"
                :value="key"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="学校">
            <el-input v-model="form.educations[i-1].school"></el-input>
          </el-form-item>
          <el-button type="danger" @click="delete_education(i-1)">删除</el-button>
        </el-collapse-item>
      </el-collapse>
    </el-form>
    <el-form label-width="70px" class="form" v-if="step==2">
      3
    </el-form>
    <el-form label-width="70px" class="form" v-if="step==3">
      333
    </el-form>




    <el-row>
      <el-col :span="12">
        <el-button :disabled="step==0" @click="step--">
          <i class="el-icon-d-arrow-left"></i>
          返回
        </el-button>
      </el-col>
      <el-col :span="12" style="text-align:right">
        <el-button type="primary" v-if="step!=3" @click="step++">
          下一页
          <i class="el-icon-d-arrow-right"></i>
        </el-button>
        <el-button type="primary" v-if="step==3" @click="submit()">
          提交
        </el-button>
      </el-col>
    </el-row>
  </el-card>
</template>

<script>
import * as metas from '@/libs/metas';

export default {
  data(){
    return {
      step: 0,

      metas,

      //数据
      form: {
        name: '',
        gender: '',
        languages: [],
        age: 18,
        job: '',
        accept: false,
        salary: 0,
        time: '',
        educations: [{}, {}]
      },
      actives: [],
      educations: 2,
    };
  },
  methods: {
    submit(){
      fetch('/api/update', {
        method: 'post',
        headers: {
          'content-type': 'application/json'
        },
        body: JSON.stringify(this.form)
      })
    },
    async delete_education(index){
      try{
        await this.$confirm('是否确定删除此教育经历', '删除确认', {
          confirmButtonText: '删除',
          cancelButtonText: '保留',
          type: 'danger'
        });

        this.$delete(this.form.educations, index);
        this.educations--;
      }catch(e){
        //..
        console.log('取消');
      }
    }
  }
}
</script>

<style lang="css" scoped>
.header {text-align:center;}
.reg-card {width:800px; margin:0px auto 0;}
.form {margin-top:40px;}
</style>
