<template lang="html">
  <div>
      {{form}}
    <mt-header title="注册">
      <mt-button slot="left" icon="back">返回</mt-button>
      <mt-button slot="right">分享</mt-button>
    </mt-header>
    <mt-cell title="用户名">blue</mt-cell>
    <mt-cell title="用户等级">普通用户</mt-cell>
    <mt-cell title="会员有效期">永久</mt-cell>
    <mt-cell title="消费记录" is-link>15条</mt-cell>
    <mt-cell title="私信">
      15条
      <mt-badge size="small">2</mt-badge>
    </mt-cell>
    <mt-cell title="提醒">
      <mt-switch v-model="form.b"></mt-switch>
    </mt-cell>
    <mt-cell title="消费记录">
      <mt-spinner type="fading-circle"></mt-spinner>
    </mt-cell>
    <mt-cell-swipe
      v-if="show"
      title="张三"
      :right="[
        {
          content: '删除',
          style: {background: 'red', color: 'white'},
          handler: ()=>{
            this.show=false;
          }
        }
      ]"
    >
      17854875896
    </mt-cell-swipe>

    <!-- <mt-field v-model="form.username" label="用户名" placeholder="请输入用户名"></mt-field>
    <mt-field type="password" v-model="form.password" label="密码" placeholder="请输入密码"></mt-field>
    <mt-radio
      title="请选择性别"
      v-model="form.gender"
      :options="[
        {value: 'male', label: '男'},
        {value: 'female', label: '女'},
        {value: 'other', label: '其他'},
      ]"
    >
    </mt-radio>

    <mt-checklist
      title="列表"
      v-model="form.languages"
      :options="[
        {value: 'js', label: 'JavaScript开发'},
        {value: 'php', label: 'PHP开发'},
      ]"
    >
    </mt-checklist> -->

    <mt-button type="primary" size="large" @click="submit()">注册</mt-button>
    <mt-button size="large">登录</mt-button>
  </div>
</template>

<script>
export default {
  data(){
    return {
      form: {
        username: '',
        password: '',
        gender: '',
        languages: [],
        b: false
      },
      show: true
    };
  },
  methods: {
    submit(){
      // Toast({
      //   message: '短信验证码已发送',
      //   position: 'center',
      //   durations: 5000
      // });
      this.$toast({
        message: 'aaa',
        duration: 2000
      })
    }
  }
}
</script>

<style lang="css" scoped>
.header {text-align:center;}
.reg-card {width:800px; margin:0px auto 0;}
.form {margin-top:40px;}
</style>
