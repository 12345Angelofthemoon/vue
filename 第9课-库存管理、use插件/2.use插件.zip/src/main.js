import Vue from 'vue'
import App from './App.vue'

import router from './router';

Vue.config.productionTip = false

// Vue.directive('red', {
//   bind(el){
//     el.style.background='red';
//   },
// });
//
// Vue.directive('blue', {
//   bind(el){
//     el.style.background='blue';
//   },
// });

// Vue.directive('link', {
//   bind(el, binding, vnode, oldVnode){
//     el.addEventListener('click', function (){
//       vnode.context.$router.push(binding.value);
//     });
//   }
// });

// Vue.filter('time', function (value, format='YYYY-MM-dd'){
//   let oDate=new Date(value);
//   function toDou(n){
//     return n<10?`0${n}`:`${n}`;
//   }
//
//   //return oDate.getFullYear()+'-'+(oDate.getMonth()+1)+'-'+oDate.getDate();
//
//   return format
//     .replace(/YYYY/g, oDate.getFullYear())
//     .replace(/MM/g, toDou(oDate.getMonth()+1))
//     .replace(/M/g, oDate.getMonth()+1)
//     .replace(/dd/g, toDou(oDate.getDate()))
//     .replace(/d/g, oDate.getDate())
//     .replace(/HH/g, toDou(oDate.getHours()))
//     .replace(/H/g, oDate.getHours())
//
//   //YYYY  年份
//   //M     月份
//   //MM    补零月份
//   //d     日期
//   //dd    补零日期
//   //HH    24小时制小时
// });

// Vue.mixin({
//   created(){
//     console.log('a');
//   }
// })

// import myVueAxios from './myVueAxios';
// import axios from 'axios';
//
// Vue.use(myVueAxios, axios);



// Vue.use(VueAxios, axios);

// import VLink from 'v-link';
// Vue.use(VLink);

// import VAni from 'v-ani';
// Vue.use(VAni);

import MyElement from './plugins/my-element';
Vue.use(MyElement);





new Vue({
  router,
  render: h => h(App),
}).$mount('#app')
