<template lang="html">
  <div>
    <!-- <button type="button" v-link="{name: 'index'}">首页</button>
    <button type="button" v-link="{name: 'news', params: {id: 55}}">新闻1</button>
    <router-view/> -->

    <!-- <button type="button" @click="fn()">变红</button> -->

    <z-button>aaa</z-button>

    <!-- <div class="box" v-ani="{duration: 2000}" :style="{background: color, width: width+'px'}">

    </div> -->
  </div>
</template>

<script>
export default {
  name: 'app',
  data(){
    return {
      color: 'yellow',
      width: 200
    }
  },
  methods: {
    fn(){
      this.color='red';
      this.width=500;
    }
  }
}
</script>

<style lang="css" scoped>
.box {
  height:200px;
}
</style>
