import zButton from './z-button';

export default {
  install(Vue, options){
    Vue.component('z-button', zButton);
  }
}
