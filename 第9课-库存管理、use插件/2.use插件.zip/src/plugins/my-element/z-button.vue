<template lang="html">
  <button>
    <slot/>
  </button>
</template>

<script>
export default {
}
</script>

<style lang="css" scoped>
</style>
