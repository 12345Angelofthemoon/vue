export default {
  install(Vue, options){
    //..
  }
}
