export default {
  install(Vue, options){
    Vue.directive('ani', {
      bind(el, binding){
        let duration=700;
        if(binding.value){
          if(typeof binding.value=='number'){
            duration=binding.value;
          }else if(typeof binding.value=='object'){
            duration=binding.value.duration;
          }
        }

        el.style.transition=`${duration}ms all ease`;
      }
    })
  }
}
