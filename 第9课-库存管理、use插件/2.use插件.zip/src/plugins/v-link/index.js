export default {
  install(Vue){
    Vue.directive('link', {
      bind(el, binding, vnode){
        el.addEventListener('click', function (){
          if(vnode.context.$router){
            vnode.context.$router.push(binding.value);
          }
        }, false);
      }
    })
  }
}
