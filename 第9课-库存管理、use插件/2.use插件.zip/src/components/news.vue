<template lang="html">
  <div class="">
    新闻 {{$route.params.id}}
  </div>
</template>

<script>
export default {
}
</script>

<style lang="css" scoped>
</style>
