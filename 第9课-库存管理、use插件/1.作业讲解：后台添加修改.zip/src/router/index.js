import Vue from 'vue';
import Router from 'vue-router';
Vue.use(Router);

import list from '@/components/list';
import form from '@/components/form';

export default new Router({
  routes: [
    {path: '/list', name: 'list', component: list},
    {path: '/add', name: 'add', component: form},
    {path: '/edit/:id', name: 'edit', component: form},

    {path: '*', redirect: 'list'}
  ]
});
