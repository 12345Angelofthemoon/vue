<template lang="html">
  <div>
    <el-button type="primary" @click="$router.push({name: 'add'})">添加</el-button>
    <el-table :data="$store.state">

      <el-table-column
        prop="name"
        label="商品名称"
      ></el-table-column>

      <el-table-column
        prop="price"
        label="商品价格"
      ></el-table-column>

      <el-table-column
        prop="count"
        label="商品库存"
      ></el-table-column>

      <el-table-column
        label="操作"
      >
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="$router.push({name: 'edit', params: {id: scope.row.id}})">修改</el-button>
          <el-button type="text" class="del-btn" size="small" @click="del(scope.row.id)">删除</el-button>
        </template>
      </el-table-column>

    </el-table>
  </div>
</template>

<script>
export default {
  methods: {
    async del(id){
      try{
        await this.$confirm('你确定删除吗？');
        this.$store.dispatch('del', id);
      }catch(e){

      }
    }
  }
}
</script>

<style lang="css" scoped>
.del-btn {color:red}
</style>
